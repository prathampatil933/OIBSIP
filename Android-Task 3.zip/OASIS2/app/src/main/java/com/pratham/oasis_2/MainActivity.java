package com.pratham.oasis_2;

import static java.lang.Math.round;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.pratham.oasis_2.R;

public class MainActivity extends AppCompatActivity {

    EditText editText1,editText2,editText3;
    Button button1,button2,button3,button4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1=findViewById(R.id.editText1);
        editText2=findViewById(R.id.editText2);
        editText3=findViewById(R.id.editText3);

        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String firstno=editText1.getText().toString();
                String secondno=editText2.getText().toString();
                int answer= Integer.parseInt(firstno) + Integer.parseInt(secondno);
                //double answer=Double.parseDouble(firstno) + Double.parseDouble(secondno);
                editText3.setText(" Addition is : "+answer);

            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String firstno=editText1.getText().toString();
                String secondno=editText2.getText().toString();
                int answer= Integer.parseInt(firstno) - Integer.parseInt(secondno);
                editText3.setText(" Subtraction is : "+answer);

            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String firstno=editText1.getText().toString();
                String secondno=editText2.getText().toString();
                int answer= Integer.parseInt(firstno) * Integer.parseInt(secondno);
                editText3.setText(" Multiplication is : "+answer);

            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String firstno=editText1.getText().toString();
                String secondno=editText2.getText().toString();
                int answer= Integer.parseInt(firstno) / Integer.parseInt(secondno);
                editText3.setText(" Division is : "+answer);

            }
        });


    }
}